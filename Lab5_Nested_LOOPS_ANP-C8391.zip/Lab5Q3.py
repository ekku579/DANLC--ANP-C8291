def table(n):
    print(f"Multiplication Table of {n} : ")
    for i in range(1, 11):
        print(f"{n} X {i} = {i*n}")
    print("------------------------")

a = int(input("Enter the First Table of Range : "))
b = int(input("Enter the Last Table of Range : "))
for i in range(a, b + 1):
    table(i)
    

