# Patterns using functions in a single program:-
for i in range(1,6):
    for j in range(i):
        print(i,end="")
    print()

# 2nd Patterns :-
for i in range(1,6):
    for j in range(1,i+1):
        print(j,end="")
    print()

# 3rd Patterns :-
k = 1
for i in range(1,6):
    for j in range(1,i+1):
        print(k,end="")
        k = k + 1
    print()

# 4th pattern:-

for i in range(1,6):
    k = i
    for j in range(i):
        print(k,end=" ")
        k = k - 1

    for j in range(1, 4*(5-i+1)):
        print(" ", end="")

    for j in range(1, i+2):
        print(j, end=" ")
    print(" ")

# 5th pattern:-
def print_pattern(n):

    for i in range(1, n+1):
        for j in range(n, i, -1):
            print(" ", end=" ")
        for k in range(1, i+1):
            print(k, end=" ")
        for l in range(i-1, 0, -1):
            print(l, end=" ")
        print()

    for i in range(n-1, 0, -1):
        for j in range(n, i, -1):
            print(" ", end=" ")
        for k in range(1, i+1):
            print(k, end=" ")
        for l in range(i-1, 0, -1):
            print(l, end=" ")
        print()

n = 5
print_pattern(n)

# 6th pattern:-
def print_inverted_half_pyramid(n):
    for i in range(n, 0, -1):
        for j in range(1, i + 1):
            print(j, end=" ")
        print()

n = 5
print_inverted_half_pyramid(n)

# 7th pattern:-
def print_hollow_half_pyramid(n):
    for i in range(1, n+1):
        for j in range(1, i+1):
            if j == 1 or j == i or i == n:
                print(j, end=" ")
            else:
                print(" ", end=" ")
        print()

n = 5
print_hollow_half_pyramid(n)

# 8th pattern:-

def print_full_pyramid(n):
    for i in range(1, n + 1):

        for j in range(n - i):
            print(" ", end=" ")

        for k in range(i, 2 * i):
            print(k, end=" ")

        for l in range(2 * i - 2, i - 1, -1):
            print(l, end=" ")
        print()

n = 5
print_full_pyramid(n)

# 9th pattern :-

def print_hollow_full_pyramid(n):
    for i in range(1, n + 1):

        for j in range(n - i):
            print(" ", end=" ")

        for k in range(1, 2 * i):
            if k == 1 or k == 2 * i - 1 or i == n:
                print(k if k <= i else 2 * i - k, end=" ")
            else:
                print(" ", end=" ")
        print()

n = 5
print_hollow_full_pyramid(n)

# 10th pattern:-

def print_hollow_inverted_half_pyramid(n):
    for i in range(n, 0, -1):
        for j in range(1, i + 1):
            if i == n or j == 1 or j == i:
                print(j, end=" ")
            else:
                print(" ", end=" ")
        print()

n = 5
print_hollow_inverted_half_pyramid(n)

# 11th pattern:-
def print_alphabet_pyramid(n):
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    for i in range(n):

        for j in range(n - i - 1):
            print(" ", end=" ")

        for k in range(i + 1):
            print(alphabet[k], end=" ")

        for l in range(i - 1, -1, -1):
            print(alphabet[l], end=" ")
        print()

n = 26
print_alphabet_pyramid(n)













