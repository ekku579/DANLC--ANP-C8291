# Write a Python program that prompts the user to input two numbers and
# raises a TypeError exception if the inputs are not numerical
class NotNumberError(Exception):
    def __init__(self):
        super().__init__("Both number should be numerical. The number you entered is not numerical\nEnter only numerical values")

try:
    num1 = input("Enter first number: ")
    num2 = input("Enter second number: ")
    if not (num1.isdigit() and num2.isdigit()):
        raise NotNumberError
    print(f"{num1} and {num2} is numerical")
except NotNumberError as e:
    print(e)