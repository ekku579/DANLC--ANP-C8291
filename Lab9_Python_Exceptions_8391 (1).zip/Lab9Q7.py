# Custom Exceptions for Business Logic
# Create custom exception classes `OutOfStockError` and `InvalidOrderError`.
# Write a function `process_order` that takes an order (a dictionary with item names and quantities) and a stock (a dictionary with item names and available quantities) as arguments. Use exception handling to manage:
# Out of stock items (raise `OutOfStockError` with a suitable message).
# Invalid order quantities (e.g., negative or zero, raise `InvalidOrderError` with a suitable message).
# Test the function with various orders and stock scenarios.

stock1 = {"Shirt": 9, "Pants": 3}

stock2 = {"Shirt": 8, "Pants": 9}

stock3 = {"Shirt": 8, "Shoes": 5}

order1 = {"Shirt": 6, "Pants": 5}

order2 = {"Shirt": 3, "Pants": 8}

order3 = {"Shirt": 2, "Hat": 4}


class OutOfStockError(Exception):
    def __init__(self, item):
        super().__init__(f"Out of stock: {item}")

class InvalidOrderError(Exception):
    def __init__(self, item):
        super().__init__(f"Invalid order quantity for item: {item}")

def processOrder(stock, order):
    for key, value in order.items():
        try:
            if value < 1:
                raise InvalidOrderError(key)
            if key not in stock or stock[key] < value:
                raise OutOfStockError(key)
            print(f"For {key}: Order Complete")
        except InvalidOrderError as e:
            print(e)
        except OutOfStockError as e:
            print(e)


processOrder(stock1, order3)