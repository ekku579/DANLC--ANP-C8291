# Write a Python program that opens a file and handles a FileNotFoundError exception
# if the file does not exist.t.
def read_file_content(fileName):
    try:
        with open(fileName, 'r') as file:
            content = file.read()
            print(content)
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

fileName = input("Enter the file name: ")
read_file_content(fileName)