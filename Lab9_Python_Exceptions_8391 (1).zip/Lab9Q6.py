# Multiple Exception Types in User Input
# Write a function `get_valid_date` that prompts the user to enter a date in the format `YYYY-MM-DD`. Use exception handling to manage:
# Invalid format (e.g., not enough parts, non-numeric parts).
# Invalid date values (e.g., month not in 1-12, day not valid for the given month).
# Ensure the function keeps asking for input until a valid date is entered and returns a `datetime.date` object.

class InvalidFormatError(Exception):
    def __init__(self):
        super().__init__("Invalid Format")


class InvalidDateValuesError(Exception):
    def __init__(self):
        super().__init__("Date is Invalid")


def get_valid_date():
    while True:
        try:
            date = input("Enter Date: ")
            mm = int(date[5:7])
            dd = int(date[8:])
            if not (1 <= mm <= 12 and 1 <= dd <= 31):
                raise InvalidDateValuesError
            if len(date) != 10 or date[4] != '-' or date[7] != '-':
                raise InvalidFormatError

            print("Valid Date: ", date)
            break
        except InvalidFormatError as e:
            print(e)
        except InvalidDateValuesError as e:
            print(e)


get_valid_date()