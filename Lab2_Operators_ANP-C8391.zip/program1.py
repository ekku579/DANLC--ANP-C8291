# Wap to check whether a number is negative or positive.
a=int(input("Enter the number :"))
result= "The given number is Positive" if a>=0 else "The given number is Negative"
print(result)