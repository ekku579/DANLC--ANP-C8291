# Wap to print all the lower case alphabets
for i in range(ord('a'), ord('z')+1):
    print(chr(i), end=" ")

