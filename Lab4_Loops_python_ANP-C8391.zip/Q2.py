# wap to find the sum of first 10 natural numbers.
sum=0
for i in range(1,11):
    sum=sum+i
print(sum)
