# Write a Python program to Count vowels in a string
# Input = “Welcome to Python Assignment”

String_user = "Welcome to Python Assignment"
vowels = "aeiouAEIOU"

count = 0
for char in String_user:
    if char in vowels:
        count += 1
print(count)


