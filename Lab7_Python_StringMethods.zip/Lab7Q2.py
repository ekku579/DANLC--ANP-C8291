# Write a Python program to remove duplicate characters of a given string.
# Input = “String and String Function”

string_user = ("String and String Function")
string_user = string_user.split()
temp_set = set()
answer = ""

for word in string_user:
    if word in temp_set:
        continue
    else:
        temp_set.add(word)
        answer = answer + (word+" ")
print(answer)

