# Wap to search a string and replace it with another string (all occurrences)

def find_replace(fileName, findWord, replaceWord):
    try:
        with open(fileName, 'r') as file:
            content = file.read()
        replaceString = content.replace(findWord, replaceWord)
        with open(fileName, 'w') as file:
            file.write(replaceString)
        print("All occurrence of word have been replaced")
    except FileNotFoundError:
        print(f"The file {fileName} does not exist")
    except Exception as e:
        print(f"An error occurred: {e}")

fileName = input("Enter file name: ")
find = input("Enter a word that you want to find: ")
replace = input(f"Enter the word you want to replace with {find}")
find_replace(fileName, find, replace)