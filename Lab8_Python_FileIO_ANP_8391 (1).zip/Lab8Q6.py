# Wap to search a particular word in a file and also prints number of occurrences.

def count_word(fileName, word):
    count = 0
    word = word.lower()
    try:
        with open(fileName, 'r') as file:
            for line in file:
                line = line.split()
                for words in line:
                    words = words.lower()
                    if word == words:
                        count +=1
    except FileNotFoundError:
        print(f"The file {fileName} does not exist")
    except Exception as e:
        print(f"An error occurred: {e}")
    return count

fileName = input("Enter the file name: ")
word = input("Enter the word that you want to search and print number of occurrences")
occurrence = count_word(fileName, word)
print(f"Number of occurrences is: {occurrence}")