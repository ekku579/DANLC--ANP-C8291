# Write a function in python to read the content from a text file "ABC.txt" line by line
# and display the same on screen.

def read_file_content(fileName):
    try:
        with open(fileName, 'r') as file:
            for line in file:
                print(line.strip())
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

fileName = input("Enter the file name: ")
read_file_content(fileName)
