# Write a function display_words() in python to read lines from a text file "story.txt", and display those words, which are less than 4 characters.

def display_words(fileName):
    countUpper = 0
    try:
        with open(fileName, 'r') as file:
            for line in file:
                line = line.split()
                for word in line:
                    if len(word)<4:
                        print(word, end=" ")
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

fileName = input("Enter the file name: ")
display_words(fileName)