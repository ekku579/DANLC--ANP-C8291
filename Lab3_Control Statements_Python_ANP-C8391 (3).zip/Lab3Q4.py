#  Wap to check if the user has provided the correct currency note for deposit or not.
#  The note should be in between the following currencies:-     2000, 500, 200, 100, 50

a=int(input("Enter the currency note : "))
if a==50 or a==100 or a==200 or a==500 or a==2000 :
    print("Currency Note")
else :
    print("This is not Currency Note")


# Second Method
b= int(input("Enter the currency note : "))
list=[50,100,200.500,2000]
if b in list :
    print("Currency Note")
else :
    print("This is not a Currency Note")
    