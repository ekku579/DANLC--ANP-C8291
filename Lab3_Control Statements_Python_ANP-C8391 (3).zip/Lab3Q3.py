#  Wap to check login and password
UserID= "bangariyogesh2003@gmail.com"
UserPass="Yogi@7838"

uid=input("Enter the userid : ")
if uid==UserID :
    upass=input("Enter the Password : ")
    if UserPass==upass :
        print("Login Succesfully")
    else :
        print("Incorrect Password")
else :
    print("UserID is Incorrect")
