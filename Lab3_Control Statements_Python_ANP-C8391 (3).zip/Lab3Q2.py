#  Wap to check whether a number is negative, positive or zero

num=float(input("Enter any number : "))
if num>0 :
    print("Positive Number")
elif num<0 :
    print("Negative Number")
else :
    print("Zero")