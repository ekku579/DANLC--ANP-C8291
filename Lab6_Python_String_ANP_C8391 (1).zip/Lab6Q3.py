# Write a Python program to reverse words in a string
# String = “Deeptech Python Training”

str1 = "Deeptech Python Training"

str = str1.split()

str2 = ""

for word in str:
    str2 += word[::-1]+" "
print(str2)
