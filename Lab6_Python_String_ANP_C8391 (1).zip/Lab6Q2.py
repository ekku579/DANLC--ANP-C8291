# Write a Python program to remove a newline in Python
# String = "\nBest \nDeeptech \nPython \nTraining\n"

string = "\nBest \nDeeptech \nPython \nTraining\n"

cleaned_string = string.replace('\n', ' ')

print(cleaned_string)


