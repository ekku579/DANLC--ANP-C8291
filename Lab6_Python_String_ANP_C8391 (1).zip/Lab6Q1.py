# Write a Python program to count the occurrences of each word in a given sentence
# string = “To change the overall look of your document.To change the look available in the gallery”


string = "To change the overall look of your document. To change the look available in the gallery"

string = string.lower()

for char in "-.,\n":
    string = string.replace(char, " ")

words = string.split()

word_counts = {}

for word in words:
    word_counts[word] = word_counts.get(word, 0) + 1

print(word_counts)

